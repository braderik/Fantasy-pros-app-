class TradeFinderApp {
    constructor() {
        this.config = null;
        this.initializeEventListeners();
        this.loadConfig();
    }

    initializeEventListeners() {
        document.getElementById('config-form').addEventListener('submit', this.handleConfigSubmit.bind(this));
        document.getElementById('import-league').addEventListener('click', this.handleImportLeague.bind(this));
        document.getElementById('refresh-rankings').addEventListener('click', this.handleRefreshRankings.bind(this));
        document.getElementById('find-trades').addEventListener('click', this.handleFindTrades.bind(this));
    }

    async loadConfig() {
        try {
            const response = await fetch('/config');
            this.config = await response.json();
            this.populateConfigForm();
        } catch (error) {
            this.showMessage('Failed to load configuration', 'error');
        }
    }

    populateConfigForm() {
        if (this.config.platform) {
            document.getElementById('platform').value = this.config.platform;
        }
        if (this.config.league_id) {
            document.getElementById('league_id').value = this.config.league_id;
        }
        document.getElementById('scoring_format').value = this.config.scoring.format;
        document.getElementById('te_premium').checked = this.config.te_premium;
        
        this.updateButtonStates();
    }

    async handleConfigSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const config = {
            platform: formData.get('platform'),
            league_id: formData.get('league_id'),
            scoring: {
                format: formData.get('scoring_format'),
                pass_td: 4,
                bonus: {"rec_100": 0, "rush_100": 0, "rec_200": 0, "pass_300": 0}
            },
            roster_slots: {"QB": 1, "RB": 2, "WR": 2, "TE": 1, "FLEX": 1, "SUPERFLEX": 0, "BENCH": 6},
            te_premium: formData.has('te_premium')
        };

        try {
            const response = await fetch('/config', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(config)
            });

            if (response.ok) {
                this.config = config;
                this.showMessage('Configuration saved successfully', 'success');
                this.updateButtonStates();
            } else {
                throw new Error('Failed to save configuration');
            }
        } catch (error) {
            this.showMessage('Failed to save configuration', 'error');
        }
    }

    async handleImportLeague() {
        if (!this.config.platform || !this.config.league_id) {
            this.showMessage('Please configure platform and league ID first', 'error');
            return;
        }

        try {
            this.showMessage('Importing league data...', 'info');
            const response = await fetch(`/league/import?platform=${this.config.platform}&league_id=${this.config.league_id}`);
            
            if (response.ok) {
                const data = await response.json();
                this.showMessage('League data imported successfully', 'success');
                this.updateButtonStates();
            } else {
                throw new Error('Failed to import league data');
            }
        } catch (error) {
            this.showMessage('Failed to import league data', 'error');
        }
    }

    async handleRefreshRankings() {
        try {
            this.showMessage('Refreshing FantasyPros rankings...', 'info');
            const response = await fetch('/rankings/refresh', { method: 'POST' });
            
            if (response.ok) {
                this.showMessage('Rankings refreshed successfully', 'success');
                this.updateButtonStates();
            } else {
                throw new Error('Failed to refresh rankings');
            }
        } catch (error) {
            this.showMessage('Failed to refresh rankings', 'error');
        }
    }

    async handleFindTrades() {
        if (!this.config.league_id) {
            this.showMessage('Please import league data first', 'error');
            return;
        }

        try {
            this.showMessage('Finding trade opportunities...', 'info');
            
            const response = await fetch('/trade-ideas', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    my_team_id: "user_team", // TODO: Get actual team ID
                    max_players_per_side: 2,
                    consider_2_for_1: true
                })
            });

            if (response.ok) {
                const data = await response.json();
                this.displayTradeIdeas(data);
                this.showMessage(`Found ${data.ideas.length} trade opportunities`, 'success');
            } else {
                throw new Error('Failed to find trades');
            }
        } catch (error) {
            this.showMessage('Failed to find trades', 'error');
        }
    }

    displayTradeIdeas(data) {
        const tbody = document.querySelector('#trades-table tbody');
        tbody.innerHTML = '';

        data.ideas.forEach(trade => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${trade.send.map(p => `${p.player} (${p.pos})`).join(', ')}</td>
                <td>${trade.receive.map(p => `${p.player} (${p.pos})`).join(', ')}</td>
                <td>+${trade.score_me.toFixed(1)}</td>
                <td>+${trade.score_them.toFixed(1)}</td>
                <td>${trade.notes}</td>
            `;
            tbody.appendChild(row);
        });

        document.getElementById('trades-container').classList.remove('hidden');
    }

    updateButtonStates() {
        const hasConfig = this.config && this.config.platform && this.config.league_id;
        document.getElementById('import-league').disabled = !hasConfig;
        document.getElementById('refresh-rankings').disabled = false;
        document.getElementById('find-trades').disabled = !hasConfig;
    }

    showMessage(message, type) {
        const messageDiv = document.getElementById('status-message');
        messageDiv.textContent = message;
        messageDiv.className = `status-message ${type}`;
        messageDiv.style.display = 'block';
        
        if (type === 'success' || type === 'info') {
            setTimeout(() => {
                messageDiv.style.display = 'none';
            }, 3000);
        }
    }
}

// Initialize the app when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new TradeFinderApp();
});