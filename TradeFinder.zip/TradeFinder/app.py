from fastapi import FastAPI, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
import os
from typing import Dict, List, Optional

# Import our models and services
from core.models import (
    LeagueConfig, TradeRequest, TradeResponse, 
    Player, Team, Roster
)
from core.cache import cache_manager
from services.sleeper import sleeper_service
from services.yahoo import yahoo_service  
from services.espn import espn_service
from services.fantasypros import fantasypros_service
from core.mapping import mapping_service
from core.vor import vor_calculator
from core.trade import trade_analyzer

app = FastAPI(title="Trade Finder", description="Fantasy Football Trade Finder API", version="1.0.0")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$|^https://[a-z0-9-]+\.(replit\.dev|repl\.co)$",
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# In-memory storage for league configuration
current_config: Optional[LeagueConfig] = None
league_data: Dict = {}

# Mount static files
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def serve_index():
    """Serve the main frontend page"""
    return FileResponse("static/index.html")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    fantasypros_available = fantasypros_service.is_api_available()
    
    return {
        "ok": True,
        "fantasypros_api": fantasypros_available,
        "status": "ready" if fantasypros_available else "limited"
    }

@app.get("/config")
async def get_config():
    """Get current league configuration"""
    if current_config:
        return current_config.dict()
    
    # Return default configuration
    return LeagueConfig().dict()

@app.post("/config")
async def save_config(config: LeagueConfig):
    """Save league configuration"""
    global current_config
    current_config = config
    
    # Clear any cached league data when config changes
    global league_data
    league_data.clear()
    
    return {"message": "Configuration saved successfully", "config": config.dict()}

@app.get("/league/import")
async def import_league(platform: str = Query(...), league_id: str = Query(...)):
    """Import league data from specified platform"""
    try:
        if platform.lower() == "sleeper":
            data = await sleeper_service.import_league_data(league_id)
        elif platform.lower() == "yahoo":
            data = await yahoo_service.import_league_data(league_id)
        elif platform.lower() == "espn":
            data = await espn_service.import_league_data(league_id)
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported platform: {platform}")
        
        # Store league data
        global league_data
        league_data = data
        
        # Extract players for mapping
        all_players = []
        for roster_data in data.get("rosters", []):
            for player_data in roster_data.get("players", []):
                player = Player(**player_data)
                all_players.append(player)
        
        # Attempt to map players to FantasyPros (optional - graceful failure)
        if all_players and fantasypros_service.is_api_available():
            try:
                await mapping_service.map_players(platform, all_players)
            except Exception as e:
                print(f"Warning: Player mapping failed: {e}")
        
        return {
            "message": "League data imported successfully",
            "teams": len(data.get("teams", [])),
            "total_players": len(all_players),
            "platform": platform,
            "league_id": league_id
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to import league data: {str(e)}")

@app.post("/rankings/refresh")
async def refresh_rankings():
    """Refresh FantasyPros rankings and projections"""
    try:
        if not fantasypros_service.is_api_available():
            raise HTTPException(
                status_code=503, 
                detail="FantasyPros API not available. Please add FANTASYPROS_API_KEY to secrets."
            )
        
        if not current_config:
            raise HTTPException(status_code=400, detail="Please configure league settings first")
        
        # Refresh FantasyPros data
        scoring_format = current_config.scoring.format
        fp_players = await fantasypros_service.get_ros_values(
            scoring=scoring_format, 
            force_refresh=True
        )
        
        return {
            "message": "Rankings refreshed successfully",
            "players_updated": len(fp_players),
            "scoring_format": scoring_format
        }
        
    except ValueError as e:
        if "FantasyPros API key" in str(e):
            raise HTTPException(status_code=503, detail=str(e))
        raise HTTPException(status_code=500, detail=f"Failed to refresh rankings: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to refresh rankings: {str(e)}")

@app.post("/trade-ideas")
async def generate_trade_ideas(request: TradeRequest):
    """Generate trade ideas for the specified team"""
    try:
        if not league_data:
            raise HTTPException(status_code=400, detail="Please import league data first")
        
        if not current_config:
            raise HTTPException(status_code=400, detail="Please configure league settings first")
        
        # Get FantasyPros data
        fp_players = cache_manager.get_all_fantasypros_players()
        if not fp_players:
            if not fantasypros_service.is_api_available():
                raise HTTPException(
                    status_code=503, 
                    detail="FantasyPros API not available. Please add FANTASYPROS_API_KEY to secrets and refresh rankings."
                )
            raise HTTPException(status_code=400, detail="Please refresh rankings first")
        
        # Parse rosters from league data
        rosters = []
        for roster_data in league_data.get("rosters", []):
            players = [Player(**p) for p in roster_data.get("players", [])]
            roster = Roster(team_id=roster_data["team_id"], players=players)
            rosters.append(roster)
        
        # Find my roster
        my_roster = None
        for roster in rosters:
            if roster.team_id == request.my_team_id:
                my_roster = roster
                break
        
        if not my_roster:
            raise HTTPException(status_code=404, detail="Team not found")
        
        # Get all players for VOR calculation
        all_players = []
        for roster in rosters:
            all_players.extend(roster.players)
        
        # Calculate VOR values
        vor_values = vor_calculator.calculate_vor(
            players=all_players,
            fp_players=fp_players,
            roster_slots=current_config.roster_slots,
            scoring=current_config.scoring,
            te_premium=current_config.te_premium,
            num_teams=len(rosters)
        )
        
        # Generate trade ideas
        trade_ideas = trade_analyzer.generate_trade_ideas(
            my_roster=my_roster,
            all_rosters=rosters,
            vor_values=vor_values,
            roster_slots=current_config.roster_slots,
            max_players_per_side=request.max_players_per_side,
            consider_2_for_1=request.consider_2_for_1
        )
        
        return TradeResponse(ideas=trade_ideas)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate trade ideas: {str(e)}")

@app.get("/mapping/misses")
async def get_mapping_misses():
    """Get list of players that couldn't be mapped to FantasyPros"""
    try:
        if not league_data or not current_config:
            return {"unmapped_players": []}
        
        # Get all players from league data
        all_players = []
        for roster_data in league_data.get("rosters", []):
            for player_data in roster_data.get("players", []):
                player = Player(**player_data)
                all_players.append(player)
        
        # Get unmapped players
        platform = current_config.platform
        if not platform:
            return {"unmapped_players": []}
        
        unmapped = mapping_service.get_mapping_misses(platform, all_players)
        
        return {
            "unmapped_players": [
                {
                    "id": p.id,
                    "name": p.name,
                    "position": p.position,
                    "team": p.team
                } for p in unmapped
            ]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get mapping misses: {str(e)}")

@app.post("/mapping/override")
async def save_mapping_override(
    platform_player_id: str,
    fp_slug: str,
    player_name: str,
    position: str,
    team: str
):
    """Save a manual player mapping override"""
    try:
        if not current_config:
            raise HTTPException(status_code=400, detail="Please configure league settings first")
        
        platform = current_config.platform
        if not platform:
            raise HTTPException(status_code=400, detail="Platform not configured")
        
        mapping_service.save_manual_mapping(
            platform=platform,
            platform_player_id=platform_player_id,
            fp_slug=fp_slug,
            player_name=player_name,
            position=position,
            team=team
        )
        
        return {"message": "Player mapping saved successfully"}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save mapping: {str(e)}")

@app.get("/roster/{team_id}")
async def get_team_roster(team_id: str):
    """Get roster for a specific team with VOR values"""
    try:
        if not league_data or not current_config:
            raise HTTPException(status_code=400, detail="Please import league data first")
        
        # Find the roster
        roster_data = None
        for r in league_data.get("rosters", []):
            if r["team_id"] == team_id:
                roster_data = r
                break
        
        if not roster_data:
            raise HTTPException(status_code=404, detail="Team not found")
        
        # Get FantasyPros data for VOR calculation
        fp_players = cache_manager.get_all_fantasypros_players()
        if not fp_players:
            raise HTTPException(status_code=400, detail="Please refresh rankings first")
        
        # Create player objects
        players = [Player(**p) for p in roster_data.get("players", [])]
        
        # Get all players for VOR calculation context
        all_players = []
        for r in league_data.get("rosters", []):
            for p in r.get("players", []):
                all_players.append(Player(**p))
        
        # Calculate VOR
        vor_values = vor_calculator.calculate_vor(
            players=all_players,
            fp_players=fp_players,
            roster_slots=current_config.roster_slots,
            scoring=current_config.scoring,
            te_premium=current_config.te_premium,
            num_teams=len(league_data.get("rosters", []))
        )
        
        # Add VOR to players
        roster_with_vor = []
        for player in players:
            player_dict = player.dict()
            player_dict["vor"] = round(vor_values.get(player.id, 0.0), 1)
            roster_with_vor.append(player_dict)
        
        # Sort by VOR descending
        roster_with_vor.sort(key=lambda p: p["vor"], reverse=True)
        
        return {"team_id": team_id, "players": roster_with_vor}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get roster: {str(e)}")

@app.get("/teams")
async def get_teams():
    """Get all teams in the league"""
    if not league_data:
        raise HTTPException(status_code=400, detail="Please import league data first")
    
    return {"teams": league_data.get("teams", [])}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)