#!/usr/bin/env python3
"""
Test script to verify Trade Finder functionality without external APIs
"""
import asyncio
import json
from core.models import Player, Team, Roster, LeagueConfig, Scoring, RosterSlots, FantasyProPlayer
from core.vor import vor_calculator
from core.trade import trade_analyzer
from core.cache import cache_manager

# Sample player data representing a realistic fantasy football league
sample_players = [
    # Team 1 (User's team) - Strong at QB/WR, weak at RB
    {"id": "p1", "name": "Josh Allen", "position": "QB", "team": "BUF", "ros_points": 24.5},
    {"id": "p2", "name": "Stefon Diggs", "position": "WR", "team": "BUF", "ros_points": 18.2},
    {"id": "p3", "name": "Tyreek Hill", "position": "WR", "team": "MIA", "ros_points": 19.1},
    {"id": "p4", "name": "Alexander Mattison", "position": "RB", "team": "MIN", "ros_points": 9.3},
    {"id": "p5", "name": "Raheem Mostert", "position": "RB", "team": "MIA", "ros_points": 11.2},
    {"id": "p6", "name": "Travis Kelce", "position": "TE", "team": "KC", "ros_points": 16.8},
    {"id": "p7", "name": "Gabe Davis", "position": "WR", "team": "BUF", "ros_points": 12.4},
    {"id": "p8", "name": "Tyler Higbee", "position": "TE", "team": "LAR", "ros_points": 8.1},
    
    # Team 2 - Strong at RB, needs WR help
    {"id": "p9", "name": "Dak Prescott", "position": "QB", "team": "DAL", "ros_points": 20.1},
    {"id": "p10", "name": "Christian McCaffrey", "position": "RB", "team": "SF", "ros_points": 22.3},
    {"id": "p11", "name": "Josh Jacobs", "position": "RB", "team": "LV", "ros_points": 16.7},
    {"id": "p12", "name": "Jerry Jeudy", "position": "WR", "team": "DEN", "ros_points": 11.8},
    {"id": "p13", "name": "Courtland Sutton", "position": "WR", "team": "DEN", "ros_points": 10.5},
    {"id": "p14", "name": "Darren Waller", "position": "TE", "team": "NYG", "ros_points": 12.1},
    {"id": "p15", "name": "Rhamondre Stevenson", "position": "RB", "team": "NE", "ros_points": 14.2},
    {"id": "p16", "name": "DJ Moore", "position": "WR", "team": "CHI", "ros_points": 13.7},
    
    # Team 3 - Balanced roster
    {"id": "p17", "name": "Lamar Jackson", "position": "QB", "team": "BAL", "ros_points": 23.1},
    {"id": "p18", "name": "Derrick Henry", "position": "RB", "team": "TEN", "ros_points": 18.9},
    {"id": "p19", "name": "DeAndre Hopkins", "position": "WR", "team": "TEN", "ros_points": 15.6},
    {"id": "p20", "name": "Amon-Ra St. Brown", "position": "WR", "team": "DET", "ros_points": 16.3},
    {"id": "p21", "name": "Tony Pollard", "position": "RB", "team": "DAL", "ros_points": 13.4},
    {"id": "p22", "name": "Mark Andrews", "position": "TE", "team": "BAL", "ros_points": 14.5},
    {"id": "p23", "name": "Jaylen Waddle", "position": "WR", "team": "MIA", "ros_points": 14.8},
    {"id": "p24", "name": "Dameon Pierce", "position": "RB", "team": "HOU", "ros_points": 12.6}
]

async def test_vor_calculation():
    """Test VOR calculation with sample data"""
    print("=== Testing VOR Calculation ===")
    
    # Create league config
    config = LeagueConfig(
        platform="test",
        league_id="test123",
        scoring=Scoring(format="PPR"),
        roster_slots=RosterSlots(),
        te_premium=False
    )
    
    # Convert sample data to Player objects
    players = [Player(**p) for p in sample_players]
    
    # Create FantasyPros-style players for VOR calculation
    fp_players = []
    for p in players:
        fp_players.append(FantasyProPlayer(
            player_name=p.name,
            position=p.position,
            team=p.team,
            ecr_rank=1,
            ros_points=p.ros_points or 0,
            last_updated=datetime.now()
        ))
    
    # Calculate VOR baselines and scores
    baselines = vor_calculator.calculate_replacement_baselines(fp_players, config.roster_slots)
    vor_scores = {}
    
    for i, player in enumerate(players):
        vor = vor_calculator.calculate_vor(
            player.ros_points or 0,
            baselines.get(player.position, 0),
            player.position,
            config.te_premium
        )
        vor_scores[player.id] = vor
        # Also set VOR on player object
        player.vor = vor
    
    print(f"Calculated VOR for {len(vor_scores)} players:")
    sorted_vor = sorted(vor_scores.items(), key=lambda x: x[1], reverse=True)
    
    for player_id, vor in sorted_vor[:10]:  # Top 10
        player = next(p for p in players if p.id == player_id)
        print(f"  {player.name} ({player.position}): VOR = {vor:.2f}")
    
    return vor_scores

async def test_trade_analysis():
    """Test trade analysis with sample rosters"""
    print("\n=== Testing Trade Analysis ===")
    
    # Create sample rosters
    team1_players = sample_players[:8]  # First 8 players
    team2_players = sample_players[8:16]  # Next 8 players
    team3_players = sample_players[16:]  # Remaining players
    
    rosters = [
        Roster(team_id="team1", players=[Player(**p) for p in team1_players]),
        Roster(team_id="team2", players=[Player(**p) for p in team2_players]),
        Roster(team_id="team3", players=[Player(**p) for p in team3_players])
    ]
    
    config = LeagueConfig(
        platform="test",
        league_id="test123", 
        scoring=Scoring(format="PPR"),
        roster_slots=RosterSlots(),
        te_premium=False
    )
    
    # Get VOR scores (using same calculation as before)
    all_players = [Player(**p) for p in sample_players]
    fp_players = []
    for p in all_players:
        fp_players.append(FantasyProPlayer(
            player_name=p.name,
            position=p.position,
            team=p.team,
            ecr_rank=1,
            ros_points=p.ros_points or 0,
            last_updated=datetime.now()
        ))
    
    baselines = vor_calculator.calculate_replacement_baselines(fp_players, config.roster_slots)
    vor_scores = {}
    
    for player in all_players:
        vor = vor_calculator.calculate_vor(
            player.ros_points or 0,
            baselines.get(player.position, 0),
            player.position,
            config.te_premium
        )
        vor_scores[player.id] = vor
    
    # Generate trades for team1 (index 0)
    trades = trade_analyzer.generate_trade_ideas(rosters[0], rosters, vor_scores, config.roster_slots)
    
    print(f"Found {len(trades)} potential trades for Team 1:")
    for i, trade in enumerate(trades[:5]):  # Show top 5 trades
        give_names = [p.player for p in trade.send]
        receive_names = [p.player for p in trade.receive]
        print(f"  Trade {i+1}: Give {give_names} → Receive {receive_names}")
        print(f"    My improvement: {trade.score_me:.2f}, Their improvement: {trade.score_them:.2f}")
        print(f"    Notes: {trade.notes}")
    
    return trades

async def main():
    """Run all tests"""
    print("Trade Finder - Core Functionality Test (No External APIs)\n")
    
    try:
        # Test VOR calculation
        vor_scores = await test_vor_calculation()
        
        # Test trade analysis
        trades = await test_trade_analysis()
        
        print(f"\n=== Test Summary ===")
        print(f"✅ VOR calculation: {len(vor_scores)} players processed")
        print(f"✅ Trade analysis: {len(trades)} trades generated")
        print("✅ All core functionality working without external APIs!")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())