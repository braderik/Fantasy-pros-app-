import os
import httpx
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from core.models import FantasyProPlayer
from core.cache import cache_manager

class FantasyProService:
    """Service for interacting with FantasyPros API"""
    
    def __init__(self):
        self.api_key = os.getenv("FANTASYPROS_API_KEY")
        self.base_url = "https://api.fantasypros.com/v2"
        self.timeout = 30
        self._api_available = None
    
    def is_api_available(self) -> bool:
        """Check if FantasyPros API is available"""
        if self._api_available is None:
            self._api_available = bool(self.api_key)
        return self._api_available
    
    def _ensure_api_available(self):
        """Ensure API is available or raise appropriate error"""
        if not self.is_api_available():
            raise ValueError("FantasyPros API key not configured. Please add FANTASYPROS_API_KEY to secrets.")
    
    def get_headers(self) -> Dict[str, str]:
        """Get API headers with authentication"""
        return {
            "x-api-key": self.api_key or "",
            "Content-Type": "application/json",
            "User-Agent": "Trade-Finder/1.0"
        }
    
    async def _make_request(self, endpoint: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """Make authenticated request to FantasyPros API"""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(url, headers=self.get_headers(), params=params or {})
            response.raise_for_status()
            return response.json()
    
    async def get_ros_values(self, year: Optional[int] = None, 
                           scoring: str = "PPR", 
                           position: Optional[str] = None,
                           force_refresh: bool = False) -> List[FantasyProPlayer]:
        """
        Get Rest of Season (ROS) player values from FantasyPros
        
        Args:
            year: Season year (defaults to current year)
            scoring: Scoring format (PPR, HALF, STD)
            position: Position filter (QB, RB, WR, TE, K, DST)
            force_refresh: Skip cache and fetch fresh data
        """
        self._ensure_api_available()
        if year is None:
            year = datetime.now().year
        
        cache_key = f"fps_ros_{year}_{scoring}_{position or 'all'}"
        
        # Check cache first unless force refresh
        if not force_refresh:
            cached_data = cache_manager.get_cache(cache_key)
            if cached_data:
                return [FantasyProPlayer(**player) for player in cached_data]
        
        # Prepare API parameters
        params = {
            "year": year,
            "scoring": scoring.upper()
        }
        if position:
            params["position"] = position.upper()
        
        try:
            # Fetch from FantasyPros API - using ROS projections endpoint
            data = await self._make_request("/projections/ros", params)
            
            players = []
            for player_data in data.get("players", []):
                player = FantasyProPlayer(
                    player_name=player_data.get("player_name", ""),
                    position=player_data.get("position", ""),
                    team=player_data.get("team", ""),
                    fp_id=player_data.get("player_id"),
                    fp_slug=player_data.get("player_slug", 
                            self._generate_slug(player_data.get("player_name", ""))),
                    ecr_rank=player_data.get("rank", 999),
                    ros_points=float(player_data.get("fpts", 0.0)),
                    last_updated=datetime.now()
                )
                players.append(player)
            
            # Sort by rank for consistency
            players.sort(key=lambda p: p.ecr_rank)
            
            # Cache the results for 24 hours
            cache_data = [player.dict() for player in players]
            cache_manager.set_cache(cache_key, cache_data, ttl_hours=24)
            
            # Also save to database
            cache_manager.save_fantasypros_players(players)
            
            return players
            
        except httpx.HTTPError as e:
            # Fallback to cached data if API fails
            print(f"FantasyPros API error: {e}")
            cached_data = cache_manager.get_cache(cache_key)
            if cached_data:
                return [FantasyProPlayer(**player) for player in cached_data]
            
            # If no cache, return empty list or raise
            return []
    
    async def get_rankings(self, position: str = "ALL", 
                          scoring: str = "PPR",
                          week: Optional[int] = None) -> List[FantasyProPlayer]:
        """
        Get expert consensus rankings
        
        Args:
            position: Position to rank (QB, RB, WR, TE, ALL)
            scoring: Scoring format
            week: Week number (None for ROS)
        """
        self._ensure_api_available()
        cache_key = f"fps_rankings_{position}_{scoring}_{week or 'ros'}"
        
        cached_data = cache_manager.get_cache(cache_key)
        if cached_data:
            return [FantasyProPlayer(**player) for player in cached_data]
        
        params = {
            "position": position.upper(),
            "scoring": scoring.upper()
        }
        if week:
            params["week"] = str(week)
        
        try:
            endpoint = "/rankings/ros" if week is None else f"/rankings/{week}"
            data = await self._make_request(endpoint, params)
            
            players = []
            for rank, player_data in enumerate(data.get("players", []), 1):
                player = FantasyProPlayer(
                    player_name=player_data.get("player_name", ""),
                    position=player_data.get("position", position if position != "ALL" else ""),
                    team=player_data.get("team", ""),
                    fp_id=player_data.get("player_id"),
                    fp_slug=player_data.get("player_slug", 
                            self._generate_slug(player_data.get("player_name", ""))),
                    ecr_rank=rank,
                    ros_points=float(player_data.get("avg", 0.0)),
                    last_updated=datetime.now()
                )
                players.append(player)
            
            # Cache for 24 hours
            cache_data = [player.dict() for player in players]
            cache_manager.set_cache(cache_key, cache_data, ttl_hours=24)
            
            return players
            
        except httpx.HTTPError as e:
            print(f"FantasyPros rankings API error: {e}")
            return []
    
    def _generate_slug(self, player_name: str) -> str:
        """Generate a slug from player name"""
        if not player_name:
            return ""
        
        # Basic slug generation: lowercase, replace spaces with hyphens, remove special chars
        slug = player_name.lower()
        slug = ''.join(c if c.isalnum() or c in ' -' else '' for c in slug)
        slug = '-'.join(slug.split())
        return slug
    
    async def search_player(self, name: str, position: Optional[str] = None) -> Optional[FantasyProPlayer]:
        """Search for a player by name"""
        self._ensure_api_available()
        cache_key = f"fps_search_{name.lower()}_{position or 'any'}"
        
        cached_result = cache_manager.get_cache(cache_key)
        if cached_result:
            return FantasyProPlayer(**cached_result) if cached_result else None
        
        params = {"name": name}
        if position:
            params["position"] = position.upper()
        
        try:
            data = await self._make_request("/players/search", params)
            
            if data.get("players"):
                player_data = data["players"][0]  # Take first result
                player = FantasyProPlayer(
                    player_name=player_data.get("player_name", ""),
                    position=player_data.get("position", ""),
                    team=player_data.get("team", ""),
                    fp_id=player_data.get("player_id"),
                    fp_slug=player_data.get("player_slug", self._generate_slug(name)),
                    ecr_rank=player_data.get("rank", 999),
                    ros_points=float(player_data.get("fpts", 0.0)),
                    last_updated=datetime.now()
                )
                
                # Cache result for 24 hours
                cache_manager.set_cache(cache_key, player.dict(), ttl_hours=24)
                return player
            
            # Cache negative result for shorter time
            cache_manager.set_cache(cache_key, None, ttl_hours=6)
            return None
            
        except httpx.HTTPError as e:
            print(f"FantasyPros search API error: {e}")
            return None

# Global service instance
fantasypros_service = FantasyProService()