import httpx
from typing import List, Dict, Any, Optional
from core.models import Team, Player, Roster

class SleeperService:
    """Service for interacting with Sleeper API"""
    
    def __init__(self):
        self.base_url = "https://api.sleeper.app/v1"
        self.timeout = 30
    
    async def _make_request(self, endpoint: str) -> Dict[str, Any]:
        """Make request to Sleeper API"""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.get(url)
            response.raise_for_status()
            return response.json()
    
    async def get_league_info(self, league_id: str) -> Dict[str, Any]:
        """Get league information"""
        return await self._make_request(f"/league/{league_id}")
    
    async def get_league_users(self, league_id: str) -> List[Dict[str, Any]]:
        """Get league users/owners"""
        result = await self._make_request(f"/league/{league_id}/users")
        return result if isinstance(result, list) else []
    
    async def get_league_rosters(self, league_id: str) -> List[Dict[str, Any]]:
        """Get league rosters"""
        result = await self._make_request(f"/league/{league_id}/rosters")
        return result if isinstance(result, list) else []
    
    async def get_all_players(self) -> Dict[str, Dict[str, Any]]:
        """Get all NFL players from Sleeper"""
        return await self._make_request("/players/nfl")
    
    async def import_league_data(self, league_id: str) -> Dict[str, Any]:
        """Import complete league data and normalize to internal models"""
        try:
            # Fetch all necessary data
            league_info = await self.get_league_info(league_id)
            users = await self.get_league_users(league_id)
            rosters = await self.get_league_rosters(league_id)
            all_players = await self.get_all_players()
            
            # Create user lookup
            user_lookup = {user["user_id"]: user for user in users}
            
            # Normalize teams
            teams = []
            for roster in rosters:
                user_id = roster.get("owner_id")
                user = user_lookup.get(user_id, {})
                
                team = Team(
                    id=str(roster["roster_id"]),
                    name=user.get("display_name", f"Team {roster['roster_id']}"),
                    owner=user.get("display_name")
                )
                teams.append(team)
            
            # Normalize rosters with players
            normalized_rosters = []
            for roster in rosters:
                players = []
                player_ids = roster.get("players", [])
                
                for player_id in player_ids:
                    player_data = all_players.get(player_id, {})
                    if player_data:
                        player = Player(
                            id=player_id,
                            name=f"{player_data.get('first_name', '')} {player_data.get('last_name', '')}".strip(),
                            position=player_data.get("position", ""),
                            team=player_data.get("team", ""),
                            player_key=player_id,
                            fp_slug=None
                        )
                        players.append(player)
                
                roster_obj = Roster(
                    team_id=str(roster["roster_id"]),
                    players=players
                )
                normalized_rosters.append(roster_obj)
            
            return {
                "league_info": league_info,
                "teams": [team.dict() for team in teams],
                "rosters": [roster.dict() for roster in normalized_rosters],
                "raw_players": all_players
            }
            
        except httpx.HTTPError as e:
            raise Exception(f"Failed to import Sleeper league data: {e}")

# Global service instance
sleeper_service = SleeperService()