# Overview

Trade Finder is a full-stack fantasy football web application that analyzes league rosters and proposes fair trade opportunities using FantasyPros rankings combined with Value Over Replacement (VOR) calculations. The app integrates with fantasy platforms (primarily Sleeper, with Yahoo/ESPN planned) to import live roster data and matches it with professional rankings to identify mutually beneficial trades.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Backend Architecture
- **Framework**: FastAPI for RESTful API endpoints with automatic OpenAPI documentation
- **Data Models**: Pydantic models for type safety and validation across league configurations, players, teams, rosters, and trade proposals
- **Service Layer**: Modular services for each fantasy platform (Sleeper implemented, Yahoo/ESPN stubbed) and FantasyPros API integration
- **Core Logic**: Separate modules for VOR calculations, player mapping, trade analysis, and caching

## Frontend Architecture
- **Technology**: Vanilla HTML/CSS/JavaScript with no frameworks for simplicity
- **UI Pattern**: Single-page application that communicates with backend API via fetch calls
- **Components**: Configuration forms, data import controls, trade results tables, and status messaging

## Data Storage
- **Primary Storage**: In-memory data structures for active session data (current league config, roster data)
- **Caching Layer**: SQLite database for persistent caching of FantasyPros data (24-hour cache), player mappings, and manual overrides
- **Cache Tables**: Separate tables for cache entries, player mappings, and FantasyPros player data with expiration handling

## Player Mapping System
- **Challenge**: Different fantasy platforms use different player identifiers
- **Solution**: Heuristic matching layer that maps platform player IDs to FantasyPros slugs using normalized name, team, and position matching
- **Manual Override**: SQLite-backed system for storing user corrections when automatic mapping fails

## VOR Calculation Engine
- **Methodology**: Calculates Value Over Replacement for each player based on league roster requirements and FantasyPros projections
- **Replacement Baseline**: Dynamically calculated per position using number of starters across all teams plus buffer
- **Adjustments**: TE premium scoring adjustments and penalties for injuries/bye weeks in trade packages

## Trade Analysis Algorithm
- **Generation**: Enumerates possible trade combinations (1-for-1, 2-for-1, 2-for-2) between user's team and all other teams
- **Scoring**: Evaluates trades based on VOR improvement for both sides, ensuring mutual benefit
- **Filtering**: Applies thresholds for minimum improvement and maximum trade size to focus on realistic proposals

# External Dependencies

## Fantasy Platform APIs
- **Sleeper API**: Fully implemented public API integration for league, roster, and player data import
- **Yahoo Fantasy API**: Planned integration requiring OAuth 2.0 implementation for private league access
- **ESPN Fantasy API**: Planned integration requiring cookie-based authentication for private leagues

## FantasyPros API
- **Purpose**: Source of professional player rankings and rest-of-season projections
- **Authentication**: API key-based authentication via `FANTASYPROS_API_KEY` environment variable
- **Endpoints**: ROS rankings and projections with position-specific filtering and scoring format options
- **Rate Limiting**: Implements caching strategy to minimize API calls and respect rate limits

## Infrastructure Dependencies
- **Python Libraries**: FastAPI, httpx, sqlite3, pydantic for core functionality
- **Frontend Assets**: Static file serving for HTML/CSS/JS with CORS middleware for cross-origin requests
- **Environment Variables**: Replit Secrets integration for secure API key and league token storage

## Database Schema
- **SQLite Tables**: Cache entries with expiration, player mappings with manual override flags, and FantasyPros player data
- **Indexing**: Unique constraints on platform/player combinations and primary keys for efficient lookups